/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.Intent
 *  android.content.res.Resources
 *  android.os.Bundle
 *  android.util.DisplayMetrics
 *  android.util.SparseBooleanArray
 *  android.util.TypedValue
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.LinearLayout
 *  android.widget.ListView
 *  android.widget.ProgressBar
 *  android.widget.TextView
 *  android.widget.Toast
 *  java.lang.CharSequence
 *  java.lang.Deprecated
 *  java.lang.Double
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Random
 *  java.util.Timer
 *  java.util.TimerTask
 */
package u.ar.black.com;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.SparseBooleanArray;
import android.util.TypedValue;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import u.ar.black.com.R;

public class HelloActivity
extends Activity {
    private Timer _timer = new Timer();
    private Intent j = new Intent();
    private LinearLayout linear1;
    private ProgressBar progressbar1;
    private TimerTask t;
    private TextView textview2;

    private void initialize(Bundle bundle) {
        this.linear1 = (LinearLayout)this.findViewById(R.id.linear1);
        this.progressbar1 = (ProgressBar)this.findViewById(R.id.progressbar1);
        this.textview2 = (TextView)this.findViewById(R.id.textview2);
        this.textview2.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
            }
        });
    }

    private void initializeLogic() {
        this.progressbar1.setMax(100);
        this.textview2.setTranslationX(-1000.0f);
        this.t = new TimerTask(){

            public void run() {
                HelloActivity.this.runOnUiThread(new Runnable(){

                    public void run() {
                        2.this.HelloActivity.this.textview2.setTranslationX(1.0f + 2.this.HelloActivity.this.textview2.getTranslationX());
                    }
                });
            }

        };
        this._timer.scheduleAtFixedRate(this.t, 700L, 2L);
        this.t = new TimerTask(){

            public void run() {
                HelloActivity.this.runOnUiThread(new Runnable(){

                    public void run() {
                        3.this.HelloActivity.this.progressbar1.setProgress(1 + 3.this.HelloActivity.this.progressbar1.getProgress());
                    }
                });
            }

        };
        this._timer.scheduleAtFixedRate(this.t, 800L, 30L);
        this.t = new TimerTask(){

            public void run() {
                HelloActivity.this.runOnUiThread(new Runnable(){

                    public void run() {
                        4.this.HelloActivity.this.finish();
                    }
                });
            }

        };
        this._timer.schedule(this.t, 5000L);
        this.t = new TimerTask(){

            public void run() {
                HelloActivity.this.runOnUiThread(new Runnable(){

                    public void run() {
                        5.this.HelloActivity.this.textview2.setTextColor(-16777216);
                        5.this.HelloActivity.this.textview2.setBackgroundColor(-1);
                        5.this.HelloActivity.this.linear1.setBackgroundColor(-16777216);
                    }
                });
            }

        };
        this._timer.schedule(this.t, 2500L);
    }

    @Deprecated
    public ArrayList<Double> getCheckedItemPositionsToArray(ListView listView) {
        ArrayList arrayList = new ArrayList();
        SparseBooleanArray sparseBooleanArray = listView.getCheckedItemPositions();
        int n = 0;
        while (n < sparseBooleanArray.size()) {
            if (sparseBooleanArray.valueAt(n)) {
                arrayList.add((Object)sparseBooleanArray.keyAt(n));
            }
            ++n;
        }
        return arrayList;
    }

    @Deprecated
    public float getDip(int n) {
        return TypedValue.applyDimension((int)1, (float)n, (DisplayMetrics)this.getResources().getDisplayMetrics());
    }

    @Deprecated
    public int getDisplayHeightPixels() {
        return this.getResources().getDisplayMetrics().heightPixels;
    }

    @Deprecated
    public int getDisplayWidthPixels() {
        return this.getResources().getDisplayMetrics().widthPixels;
    }

    @Deprecated
    public int getLocationX(View view) {
        int[] arrn = new int[2];
        view.getLocationInWindow(arrn);
        return arrn[0];
    }

    @Deprecated
    public int getLocationY(View view) {
        int[] arrn = new int[2];
        view.getLocationInWindow(arrn);
        return arrn[1];
    }

    @Deprecated
    public int getRandom(int n, int n2) {
        return n + new Random().nextInt(1 + (n2 - n));
    }

    protected void onActivityResult(int n, int n2, Intent intent) {
        super.onActivityResult(n, n2, intent);
    }

    public void onBackPressed() {
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(R.layout.hello);
        this.initialize(bundle);
        this.initializeLogic();
    }

    public void onDestroy() {
        super.onDestroy();
    }

    public void onPause() {
        super.onPause();
        this.progressbar1.setProgress(0);
        this.progressbar1.setMax(100);
        this.textview2.setTranslationX(-1000.0f);
        this.t = new TimerTask(){

            public void run() {
                HelloActivity.this.runOnUiThread(new Runnable(){

                    public void run() {
                        6.this.HelloActivity.this.textview2.setTranslationX(1.0f + 6.this.HelloActivity.this.textview2.getTranslationX());
                    }
                });
            }

        };
        this._timer.scheduleAtFixedRate(this.t, 700L, 1L);
        this.t = new TimerTask(){

            public void run() {
                HelloActivity.this.runOnUiThread(new Runnable(){

                    public void run() {
                        7.this.HelloActivity.this.progressbar1.setProgress(1 + 7.this.HelloActivity.this.progressbar1.getProgress());
                    }
                });
            }

        };
        this._timer.scheduleAtFixedRate(this.t, 800L, 15L);
    }

    protected void onPostCreate(Bundle bundle) {
        super.onPostCreate(bundle);
    }

    public void onResume() {
        super.onResume();
    }

    public void onStart() {
        super.onStart();
    }

    public void onStop() {
        super.onStop();
    }

    @Deprecated
    public void showMessage(String string2) {
        Toast.makeText((Context)this.getApplicationContext(), (CharSequence)string2, (int)0).show();
    }

}

