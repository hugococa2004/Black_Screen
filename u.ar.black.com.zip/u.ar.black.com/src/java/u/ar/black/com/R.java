/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package u.ar.black.com;

public final class R {

    public static final class attr {
    }

    public static final class color {
        public static int colorAccent = 2130968578;
        public static int colorControlHighlight = 2130968579;
        public static int colorControlNormal = 2130968580;
        public static int colorPrimary = 2130968576;
        public static int colorPrimaryDark = 2130968577;
    }

    public static final class drawable {
        public static int app_icon = 2130837504;
        public static int default_image = 2130837505;
    }

    public static final class id {
        public static int button1 = 2131165187;
        public static int button4 = 2131165188;
        public static int linear1 = 2131165184;
        public static int progressbar1 = 2131165185;
        public static int textview2 = 2131165186;
    }

    public static final class layout {
        public static int hello = 2130903040;
        public static int main = 2130903041;
    }

    public static final class string {
        public static int app_name = 2131034112;
    }

    public static final class style {
        public static int AppTheme = 2131099648;
        public static int FullScreen = 2131099649;
        public static int NoActionBar = 2131099650;
        public static int NoStatusBar = 2131099651;
    }

}

