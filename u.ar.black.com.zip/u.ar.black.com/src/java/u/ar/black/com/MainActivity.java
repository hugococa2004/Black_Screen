/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.AlertDialog
 *  android.app.AlertDialog$Builder
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnClickListener
 *  android.content.Intent
 *  android.content.SharedPreferences
 *  android.content.res.Resources
 *  android.os.Bundle
 *  android.util.DisplayMetrics
 *  android.util.SparseBooleanArray
 *  android.util.TypedValue
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.Button
 *  android.widget.LinearLayout
 *  android.widget.ListView
 *  android.widget.Toast
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Deprecated
 *  java.lang.Double
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Random
 *  java.util.Timer
 *  java.util.TimerTask
 */
package u.ar.black.com;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.SparseBooleanArray;
import android.util.TypedValue;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import u.ar.black.com.HelloActivity;
import u.ar.black.com.R;
import u.ar.black.com.SketchwareUtil;

public class MainActivity
extends Activity {
    private Timer _timer = new Timer();
    private Button button1;
    private Button button4;
    private AlertDialog.Builder hugo;
    private LinearLayout linear1;
    private SharedPreferences t;
    private Intent tr = new Intent();
    private TimerTask tu;

    private void _number(double d) {
    }

    private void initialize(Bundle bundle) {
        this.linear1 = (LinearLayout)this.findViewById(R.id.linear1);
        this.button1 = (Button)this.findViewById(R.id.button1);
        this.button4 = (Button)this.findViewById(R.id.button4);
        this.hugo = new AlertDialog.Builder((Context)this);
        this.t = this.getSharedPreferences("y", 0);
        this.linear1.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
            }
        });
        this.button1.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                SketchwareUtil.showMessage(MainActivity.this.getApplicationContext(), "You can go back with press the back button or wait :)");
                MainActivity.this.button1.setVisibility(4);
                MainActivity.this.button4.setVisibility(4);
            }
        });
        this.button4.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                MainActivity.this.hugo.setTitle((CharSequence)"About");
                MainActivity.this.hugo.setMessage((CharSequence)"Created by HugoCraft_ on Sketchware\n\nContact : hugococa2004@gmail.com\nWebsite : bit.ly/hugocraft_");
                MainActivity.this.hugo.setPositiveButton((CharSequence)"ok", new DialogInterface.OnClickListener(){

                    public void onClick(DialogInterface dialogInterface, int n) {
                    }
                });
                MainActivity.this.hugo.setNeutralButton((CharSequence)"version name", new DialogInterface.OnClickListener(){

                    public void onClick(DialogInterface dialogInterface, int n) {
                        SketchwareUtil.showMessage(3.this.MainActivity.this.getApplicationContext(), "Sunshine");
                        SketchwareUtil.showMessage(3.this.MainActivity.this.getApplicationContext(), "\ud83c\udf1e");
                        3.this.MainActivity.this.hugo.create().show();
                    }
                });
                MainActivity.this.hugo.create().show();
            }

        });
    }

    private void initializeLogic() {
        this.tr.setClass(this.getApplicationContext(), HelloActivity.class);
        this.startActivity(this.tr);
    }

    @Deprecated
    public ArrayList<Double> getCheckedItemPositionsToArray(ListView listView) {
        ArrayList arrayList = new ArrayList();
        SparseBooleanArray sparseBooleanArray = listView.getCheckedItemPositions();
        int n = 0;
        while (n < sparseBooleanArray.size()) {
            if (sparseBooleanArray.valueAt(n)) {
                arrayList.add((Object)sparseBooleanArray.keyAt(n));
            }
            ++n;
        }
        return arrayList;
    }

    @Deprecated
    public float getDip(int n) {
        return TypedValue.applyDimension((int)1, (float)n, (DisplayMetrics)this.getResources().getDisplayMetrics());
    }

    @Deprecated
    public int getDisplayHeightPixels() {
        return this.getResources().getDisplayMetrics().heightPixels;
    }

    @Deprecated
    public int getDisplayWidthPixels() {
        return this.getResources().getDisplayMetrics().widthPixels;
    }

    @Deprecated
    public int getLocationX(View view) {
        int[] arrn = new int[2];
        view.getLocationInWindow(arrn);
        return arrn[0];
    }

    @Deprecated
    public int getLocationY(View view) {
        int[] arrn = new int[2];
        view.getLocationInWindow(arrn);
        return arrn[1];
    }

    @Deprecated
    public int getRandom(int n, int n2) {
        return n + new Random().nextInt(1 + (n2 - n));
    }

    protected void onActivityResult(int n, int n2, Intent intent) {
        super.onActivityResult(n, n2, intent);
    }

    public void onBackPressed() {
        this.button1.setVisibility(0);
        this.button4.setVisibility(0);
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(R.layout.main);
        this.initialize(bundle);
        this.initializeLogic();
    }

    public void onDestroy() {
        super.onDestroy();
    }

    public void onPause() {
        super.onPause();
    }

    protected void onPostCreate(Bundle bundle) {
        super.onPostCreate(bundle);
    }

    public void onResume() {
        super.onResume();
    }

    public void onStart() {
        super.onStart();
    }

    public void onStop() {
        super.onStop();
    }

    @Deprecated
    public void showMessage(String string2) {
        Toast.makeText((Context)this.getApplicationContext(), (CharSequence)string2, (int)0).show();
    }

}

